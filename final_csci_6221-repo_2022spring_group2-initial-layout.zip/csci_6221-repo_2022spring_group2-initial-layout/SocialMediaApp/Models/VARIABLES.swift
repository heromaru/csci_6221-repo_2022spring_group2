//
//  VARIABLES.swift
//  SocialMediaApp
//
//  Created by Oğuzhan Yangöz on 4/16/22.
//

import Foundation
import Firebase

struct VARIABLES {
    static var database = Database.database().reference()
    
    
}
